class AuthorService{
   
    data = [
        { Id: 1, Name: 'Test', Gender: 'Male', Age:35,Books: ['book1','book2','book3']},
        { Id: 2, Name: 'Test2', Gender: 'Male', Age:45,Books: ['book1','book2','book3'] },
        { Id: 3, Name: 'Test3', Gender: 'Female', Age:25,Books: ['The Wall','Computer Scientist','SomeBook'] },
        { Id: 4, Name: 'Test4', Gender: 'Female', Age:55,Books: ['New Book'] } ];


     GetAllAuthors = ()=>{
       return this.data;
    };

    GetAuthor=(id)=>{
       let author = (this.data.find(i=>i.Id === id)) ;
       return author;
    };

    UpdateAuthor = (id,author)=>{
        console.log(id);
        let auth = (this.data.find(i=>i.Id === id));
        console.log(author);
        console.log(auth);
        auth.Name = author.Name;
        auth.Age =author.Age;
        auth.Gender=author.Gender;
        auth.Books = author.Books;
        this.data.concat(auth);
        console.log(this.data);
    };

    DeleteAuthor = (id)=>{
        console.log(id);
        let auth = (this.data.find(i=>i.Id === id));
        this.data.pop(auth);
    };

    AddAuthor = (author)=>{
       this.data.concat(author);
    };
}


export default AuthorService;