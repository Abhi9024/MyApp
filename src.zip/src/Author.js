import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import './bootstrap.css';
import  AuthorService from './AuthorService.js';
import PopUp from './PopUp.js';
import CustomPop from './CustomPop.js';

class Author extends Component {

 authors = new AuthorService().GetAllAuthors();
 

 editAuthor = (id,author)=>{
   new AuthorService().UpdateAuthor(id,author);
 }

 deleteAuthor = (id) =>{

  new AuthorService().DeleteAuthor(id);
 }

  render() {
    return (
  <div>
      <h3>Welcome to AuthorQuiz</h3>
      <br/>
      

<table className="table table-striped">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Name</th>
      <th scope="col">Age</th>
      <th scope="col">Gender</th>
      <th scope="col">Books</th>
      <th scope="col">Actions</th>
    </tr>
  </thead>
  <tbody>
    {this.authors.map(auth =>
       <tr>
         <th scope="row">{auth.Id}</th>
         <td>{auth.Name}</td>
         <td>{auth.Age}</td>
         <td>{auth.Gender}</td>
         <td>{auth.Books.map(b=><span>{b}, </span>)}</td>
         <td>
         <CustomPop keyId={auth.Id}  editAuthor={this.editAuthor} deleteAuthor={this.deleteAuthor}/>
         </td>
       </tr>
      )}
      
  </tbody>
</table>

<br/>

<div className="row">
<div className="col-sm-3"></div>
<div className="col-sm-3"></div>
<div className="col-sm-3"></div>
<div className="col-sm-3"></div>
<div className="col-sm-3"><input type="button" value="Add" className="btn btn-primary float-right" onClick={this.AddAuthor}/></div>

</div>
      </div>
     
    );
  }
}

export default Author;
