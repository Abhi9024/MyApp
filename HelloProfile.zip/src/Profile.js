import React, {Component}  from 'react';
import './Profile.css';
import axios from 'axios';

class Profile extends Component{

state={ data : [], };

    DisplayData=()=>{
        
        axios.get('http://localhost:14820/api/Author/GetAuthors',{ headers: { 
            'Content-Type': 'application/json',
            'Access-Control-Request-Headers' : {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods' : 'GET,PUT,POST,DELETE,PATCH,OPTIONS'},
            
          }})
        .then(res => {
            console.log(res.data);
            let updatedHeadersArray = [...res.data];
            console.log(updatedHeadersArray);
          //this.setState(prev =>({ data : res.data }));
        });
    
          
        
    };
render(){
return(
   
    <div>
        <button onClick={this.DisplayData}>Get Data</button>
        <p>{this.state.data}</p>
    </div>
)
}

}

export default Profile;